package TALN2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import requeterrezo.Mot;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;
import requeterrezo.Voisin;
import test.RezContraintes;

public class Functions {
	
	

	public static void derivationWithMotif(String X , String R , String suffixeFile , String reglesFile , String RedondanceFile) throws IOException{
		GestionnaireFichier suffixe = new GestionnaireFichier();
		List<String> lireSuffixe;
		String[] splitSuffixe;
		suffixe.ouvrir("src/TALN2/regles/"+suffixeFile,true);
		lireSuffixe=suffixe.lire();
		
		GestionnaireFichier Redondance = new GestionnaireFichier();
		Redondance.ouvrir("src/TALN2/regles/"+RedondanceFile,false);
		
		splitSuffixe=lireSuffixe.get(0).split(" ");
		for(int i=0; i<splitSuffixe.length; i++) 
		{
			derivation( X ,  R ,  splitSuffixe[i] ,  reglesFile, Redondance);
			System.out.println(i);	

		}
		suffixe.fermer();
		Redondance.fermer();


	}

	public static void derivation(String X , String R , String motif , String file ,GestionnaireFichier RedondanceFile) throws IOException{
		

		
		GestionnaireFichier regles = new GestionnaireFichier();
		List<String> lireRegles;
		String[] splitRegles;
		regles.ouvrir("src/TALN2/regles/"+file,true);
		lireRegles=regles.lire();
		
		if(motif.equals("*"))
		{
			X= X + motif;
		}
		String[] motDevise = Functions.separerMotif( X,  motif).split("#");
		//System.out.println("X : "+X+"\tmotif : "+motif);

		String motDerive;
		for(int i=0; i<lireRegles.size(); i++) 
			{
			splitRegles=lireRegles.get(i).split(";");
			if(motDevise[1].equals(splitRegles[0]))
				{
				motDerive=motDevise[0]+splitRegles[1];
				System.out.println("motDevise[1] : "+motDevise[0]+"\tsplitRegles[1] : "+splitRegles[1]);

				if(Functions.existeX(motDerive,R))
					{
					System.out.println("je rentre .................");	
					System.out.println(motDerive);	
					RedondanceFile.ecrire(motDerive);
					}

				}
			}
		System.out.println("**************************************************");	

		regles.fermer();
	}
	
	public static String conditionSeparerMotif(String X, String motif) {
		
		boolean  existeXinY;
		existeXinY= RezContraintes.existeYinX(X,motif);
		
		if(existeXinY)
		{
			return RezContraintes.separerMotif(X,motif);


		}
		else
		{
			return "motif n'existe pas";
		}

	}

	public static String separerMotif(String X, String motif) {
		return 	X = X.substring(0,X.length()-motif.length()) + "#" + X.substring(X.length()-motif.length(), X.length());

	}
	
	public static boolean existeYinX(String X, String Y) {
	    return X.matches(".*"+Y);
	}
	
	public static String r_posY(String X,String R){
		RequeterRezo rezo;
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = rezo.requete(X,R);
		Mot mot = resultatRequete.getMot();
		if(mot == null) 
		{
			return	"termeNotExiste" ;
		}
		ArrayList<Voisin> voisins = mot.getRelationsSortantesTypees(R);
		if(voisins.toString() == "[]")
			return "undef";
		String rep = null ;

		for(Voisin voisin : voisins) {
			rep=voisin.toString();
		}
		String cls = rep.toString().replaceAll("[^a-z A-Z]", "");
		return cls;
	}

	public static boolean existeX(String X,String R){
		RequeterRezo rezo;
		rezo = new RequeterRezoDump();
		Resultat resultatRequete = rezo.requete(X,R);
		Mot mot = resultatRequete.getMot();
		if(mot == null) 
		{
			return	false;
		}
		return true;
	}
	
}
