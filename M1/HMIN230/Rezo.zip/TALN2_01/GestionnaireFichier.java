package TALN2;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GestionnaireFichier {
	
	private boolean modeLecture; //True pour Lecture, False pour Ecriture
	private BufferedReader bReader;
	private BufferedWriter bWriter;
	
	public void ouvrir(String path, boolean mode) throws IOException {
		modeLecture=mode;
		if (modeLecture) {
			bReader = new BufferedReader(new FileReader(path));
		}
		else {
			bWriter = new BufferedWriter(new FileWriter(path));
		}
	}
	
	public void fermer() throws IOException {
		if(modeLecture)
			bReader.close();
		else
			bWriter.close();
	}
	
	public List<String> lire() throws IOException {
		String ligne;
		List<String> listLigne = new ArrayList<String>();
		if (modeLecture) {
			while ((ligne=bReader.readLine())!=null)
			{
				listLigne.add(ligne);
			}
		}
		
		return listLigne;
	}
	
	public void ecrire(String ligne) throws IOException {
		if (!modeLecture) {
			bWriter.write(ligne);
			bWriter.newLine();
			bWriter.flush();
		}
	}
	
}