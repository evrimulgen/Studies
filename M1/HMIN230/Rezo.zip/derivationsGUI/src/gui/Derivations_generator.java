package gui;

import static TALN2.Functions.delete_Redodance;
import static TALN2.Functions.derivationWithMotif;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;


import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import TALN2.GestionnaireFichier;
import requeterrezo.Mot;
import requeterrezo.RequeterRezo;
import requeterrezo.RequeterRezoDump;
import requeterrezo.Resultat;
import requeterrezo.Voisin;
import TALN2.Functions;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.Font;

public class Derivations_generator extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Derivations_generator frame = new Derivations_generator();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Derivations_generator() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(50,50,1200,1200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(20, 20, 900, 50);
		final JPanel panel2 = new JPanel();
		panel2.setBounds(-19, 193, 990, 583);
		contentPane.setLayout(null);
		contentPane.add(panel1);
		contentPane.add(panel2);
		panel1.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(322, 0, 304, 39);
		textField.setFont(new Font("Garuda", Font.PLAIN, 18));
		panel1.add(textField);
		textField.setColumns(20);
		panel2.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(78, 12, 900, 300);
		panel2.add(scrollPane_1);
		
		table = new JTable();
		scrollPane_1.setViewportView(table);
		table.setFillsViewportHeight(true);
		table.setFont(new Font("Khmer OS", Font.PLAIN, 20));
		table.setRowHeight(30);
		table.setToolTipText("");
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setBorder(new LineBorder(new Color(0, 0, 0), 2));
		
		//String[] columns = {"r_data", "r_domain", "r_syn", "r_fem"};
		//model.setColumnIdentifiers(columns);

		DefaultTableModel model = new DefaultTableModel();
		
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
				{" ", " ", " ", " "},
			},
			new String[] {
				"r_data", "r_domain", "r_syn", "r_fem"
			}
		));
		table.setVisible(true);
		
		Font f = new Font("Arial", Font.BOLD, 25);
		JTableHeader header = table.getTableHeader();
		header.setFont(f);
		
		JButton btnNewButton = new JButton("get Derivations");
		btnNewButton.setBounds(682, 9, 139, 25);
		panel1.add(btnNewButton);
		
		
		final JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(399, 94, 260, 90);
		contentPane.add(scrollPane);
		
		final JList list = new JList();
		scrollPane.setViewportView(list);
		list.setVisibleRowCount(5);
		list.setFont(new Font("Garuda", Font.PLAIN, 18));
		
		  list.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent arg0) {
					// TODO Auto-generated method stub
					String wordSelected = list.getSelectedValue().toString();
					DefaultTableModel model_updated = (DefaultTableModel)table.getModel();
					System.out.println(wordSelected);
					//update the table cells
					
					for(int a=0;a<model_updated.getRowCount();a++)
						for(int b=0;b<model_updated.getColumnCount();b++) 
							model_updated.setValueAt(" ", a, b);
					
					for(int j=0;j<model_updated.getColumnCount();j++){
						RequeterRezo rezo;
						rezo = new RequeterRezoDump();
						String relation_Type=" ";
						switch(j) {
							case 0:{relation_Type="r_data";}break;
							case 1:{relation_Type="r_domain";}break;
							case 2:{relation_Type="r_syn";}break;
							case 3:{relation_Type="r_fem";}break;	
						}
						Resultat resultatRequete = rezo.requete(wordSelected,relation_Type);
						Mot mot = resultatRequete.getMot();
						if(mot == null) {}
						ArrayList<Voisin> voisins = mot.getRelationsSortantesTypees(relation_Type);
						if(!(voisins.toString() == "[]")) {
							String rep = null ;
							int i=0;
							System.out.println(relation_Type);
							for(Voisin voisin : voisins) {
								rep=voisin.toString();
								if(rep != null && i<10) {
									System.out.println(rep);
									System.out.println(model_updated.getRowCount());
									model_updated.setValueAt(rep.toString().replaceAll("[^a-z A-Z]", ""), i, j);
									i++;
								}
							table.updateUI(); 
	 					}
					}
				}
			}
        });
		btnNewButton.addMouseListener(new java.awt.event.MouseAdapter()
	    {
	        public void mousePressed(java.awt.event.MouseEvent evt)
	        {
        		String R = "r_pos";
	    		String reglesFile = "regles.txt";
	    		String suffixeFile = "suffixe.txt";
	    		String RedondanceFile = "RedondanceFile.txt";
	    		String whithoutRedondanceFile = "whithoutRedondanceFile.txt";
	    	
	    		
	    		
	        	DefaultListModel<String> listModel = new DefaultListModel<>();
	        	String word=textField.getText();
				try {
					derivationWithMotif(word,R,suffixeFile, reglesFile, RedondanceFile);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					delete_Redodance(RedondanceFile,  whithoutRedondanceFile);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				GestionnaireFichier derivation = new GestionnaireFichier();
				List<String> words_derived = null;
				
				try {
					derivation.ouvrir("src/TALN2/regles/"+whithoutRedondanceFile,true);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					words_derived = derivation.lire();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				for(String s : words_derived) {
					System.out.println(s);
					listModel.addElement(s);
				}
				
				list.setModel(listModel);
				list.setVisible(true);
	    		scrollPane.updateUI();
	    		panel2.updateUI();
				System.out.println("fin du traitement");
	              
	        }
	    });

	}
}
