package TALN2;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

import static TALN2.Functions.*;


public class Derivation {

public static void main(String[] args) throws IOException {
		
		
		String X = "frapper";
		String R = "r_pos";
		String reglesFile = "regles.txt";
		String suffixeFile = "suffixe.txt";
		String RedondanceFile = "RedondanceFile.txt";
		String whithoutRedondanceFile = "whithoutRedondanceFile.txt";
		
		
		derivationWithMotif(X, R, suffixeFile, reglesFile, RedondanceFile);
		//derivation(X, R,motif, reglesFile, RedondanceFile);
//		X = X.substring(0,X.length()-motif.length()) + "#" + X.substring(X.length()-motif.length(), X.length());
//		System.out.println("X = "+X);
		
		delete_Redodance(RedondanceFile,  whithoutRedondanceFile);

	        
	}
}


