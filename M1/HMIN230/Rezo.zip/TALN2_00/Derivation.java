package TALN2;

import java.io.IOException;
import java.util.List;

import TALN2.Functions;


public class Derivation {

public static void main(String[] args) throws IOException {
		
		
		
		String X = "danser";
		String R = "r_pos";
		String motif="er";
		String file = "regles.txt";
		

		Functions.derivation( X ,  R ,  motif , file);
		
	
	}
}


