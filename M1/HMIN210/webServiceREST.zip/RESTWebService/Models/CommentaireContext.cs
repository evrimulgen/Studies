﻿using System;

using Microsoft.EntityFrameworkCore;

namespace RESTWebService.Models
{
    public class CommentaireContext : DbContext
    {
        public CommentaireContext(DbContextOptions<CommentaireContext> options)
        : base(options)
        {
        }
        public DbSet<Commentaire> comments { get; set; }
    }
}