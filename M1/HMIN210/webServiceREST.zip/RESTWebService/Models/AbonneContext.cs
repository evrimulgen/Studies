﻿using System;

using Microsoft.EntityFrameworkCore;

namespace RESTWebService.Models
{
    public class AbonneContext : DbContext
    {
        public AbonneContext(DbContextOptions<AbonneContext> options)
        : base(options)
        {
        }
        public DbSet<Abonne> abonnes { get; set; }
    }
}