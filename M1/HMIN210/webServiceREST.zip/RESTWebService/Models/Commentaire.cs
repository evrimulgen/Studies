﻿using System;

namespace RESTWebService.Models
{
    public class Commentaire
    {
        public string contenue { get; set; }
        public string reader { get; set; }
        public string livre { get; set; }
        public long Id { get; set; }
    }
}
