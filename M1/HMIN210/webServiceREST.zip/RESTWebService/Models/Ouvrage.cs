﻿using System;

namespace RESTWebService.Models
{
    public class Ouvrage
    {
        public string Id            { get; set; }
        public string titre         { get; set; }
        public string auteur        { get; set; }
        public long   nbExemplaire  { get; set; }
        public string editeur       { get; set; }
    }
}
