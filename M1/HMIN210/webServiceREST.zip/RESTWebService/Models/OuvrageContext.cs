﻿using System;

using Microsoft.EntityFrameworkCore;

namespace RESTWebService.Models
{
    public class OuvrageContext : DbContext
    {
        public OuvrageContext(DbContextOptions<OuvrageContext> options)
        : base(options)
        {
        }
        public DbSet<Ouvrage> ouvrages { get; set; }
    }
}