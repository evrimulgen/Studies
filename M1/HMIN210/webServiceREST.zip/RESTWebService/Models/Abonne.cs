﻿using System;
namespace RESTWebService.Models
{
    public class Abonne
    {
        public long Id{ get; set; }
        public string mdp { get; set; }
        
    }
}
 