
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RESTWebService.Models;

namespace RESTWebService.Controllers
{
	[Route("api/ouvrage")]
	[ApiController]
	public class OuvrageController : ControllerBase
	{
		private readonly OuvrageContext _context;
		public OuvrageController(OuvrageContext context)
		{
			_context = context;
			if (_context.ouvrages.Count() == 0)
			{
			// Create a new OuvrageItem if collection is emp‐
			ty,
			// which means you can't delete all OuvrageItems.
			_context.ouvrages.Add(new Ouvrage { Id ="KLNH-9568-NHGD-8512"   titre="l'alchimiste"      auteur="paolo cohelo"   nbExemplaire="10"    editeur="gilbert" });
			_context.SaveChanges();
			}	
		}

		//Méthodes GET
		[HttpGet]
		public async Task<ActionResult<IEnumerable<Ouvrage>>> GetOuvrage()
		{
			return await _context.ouvrages.ToListAsync();
		}
		
		[HttpGet("{Id}")]
		public async Task<ActionResult<Ouvrage>> GetOuvrage(string Id)
		{
			var ouvrage = await _context.ouvrages.FindAsync(Id);
			if ( ouvrage == null)
			{
				return NotFound();
			}
			return ouvrage;
		}

		//Méthode POST
		[HttpPost]
		public async Task<ActionResult<Ouvrage>> PostOuvrage(Ouvrage ouvrage)
		{
			_context.ouvrages.Add(ouvrage);
			await _context.SaveChangesAsync();
			return CreatedAtAction(nameof(GetOuvrage), new { Id=ouvrage.Id; titre= ouvrage.titre; auteur=ouvrage.auteur ; nbExemplaire= ouvrage.nbExemplaire; editeur= ouvrage.editeur }, ouvrage);
		}

		//Méthode PUT
		[HttpPut("{Id}")]
		public async Task<IActionResult> PutOuvrage(long Id,Ouvrage ouvrage)
		{
			if (Id != ouvrage.Id)
			{
				return BadRequest();
			}
			_context.Entry(ouvrage).State = EntityState.Modified;
			await _context.SaveChangesAsync();
			return NoContent();
		}

		//Méthode DELETE
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteOuvrage(long id)
		{
			var ouvrage = await _context.ouvrages.FindAsync(id);
			if (ouvrage == null)
			{
				return NotFound();
			}
			_context.ouvrages.Remove(ouvrage);
			await _context.SaveChangesAsync();
			return NoContent();
		}
	}
}