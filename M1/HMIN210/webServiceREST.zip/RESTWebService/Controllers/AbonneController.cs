
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RESTWebService.Models;

namespace RESTWebService.Controllers
{
	[Route("api/abonne")]
	[ApiController]
	public class AbonneController : ControllerBase
	{
		private readonly AbonneContext _context;
		public AbonneController(AbonneContext context)
		{
			_context = context;
			if (_context.abonnes.Count() == 0)
			{
			// Create a new AbonneItem if collection is emp‐
			ty,
			// which means you can't delete all AbonneItems.
			_context.abonnes.Add(new Abonne { Id =
			"412215"; mdp = "!%59!klN"  });
			_context.SaveChanges();
			}	
		}

		//Méthode GET
		[HttpGet]
		public async Task<ActionResult<IEnumerable<Abonne>>> GetAbonne()
		{
			return await _context.abonnes.ToListAsync();
		}
		
		[HttpGet("{Id}")]
		public async Task<ActionResult<Abonne>> GetAbonne(long Id)
		{
			var abonne = await _context.abonnes.FindAsync(Id);
			if ( abonne == null)
			{
				return NotFound();
			}
			return abonne;
		}

		//Méthode POST
		[HttpPost]
		public async Task<ActionResult<Abonne>> PostAbonne(Abonne abonne)
		{
			_context.abonnes.Add(abonne);
			await _context.SaveChangesAsync();
			return CreatedAtAction(nameof(GetAbonne), new { Id=Abonne.Id; mdp= Abonne.mdp}, abonne);
		}

		//Méthode PUT
		[HttpPut("{Id}")]
		public async Task<IActionResult> PutAbonne(long Id,Abonne abonne)
		{
			if (Id != abonne.Id)
			{
				return BadRequest();
			}
			_context.Entry(abonne).State = EntityState.Modified;
			await _context.SaveChangesAsync();
			return NoContent();
		}

		//Méthode DELETE
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteCommentaire(long id)
		{
			var commentaire = await _context.commentaires.FindAsync(id);
			if (commentaire == null)
			{
				return NotFound();
			}
			_context.Commentaire.Remove(commentaire);
			await _context.SaveChangesAsync();
			return NoContent();
		}

		//Méthode DELETE
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteAbonne(long id)
		{
			var abonne = await _context.abonnes.FindAsync(id);
			if (abonne == null)
			{
				return NotFound();
			}
			_context.abonnes.Remove(abonne);
			await _context.SaveChangesAsync();
			return NoContent();
		}
	}
}