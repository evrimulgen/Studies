using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RESTWebService.Models;

namespace RESTWebService.Controllers
{
	[Route("api/commentaire")]
	[ApiController]
	public class CommentaireController : ControllerBase
	{
		private readonly CommentaireContext _context;
		public CommentaireController(CommentaireContext context)
		{
			_context = context;
			if (_context.commentaires.Count() == 0)
			{
			// Create a new CommentaireItem if collection is emp‐
			ty,
			// which means you can't delete all CommentaireItems.
			_context.commentaires.Add(new Commentaire { contenue="très bon livre";reader="Terki Adel";livre="l'alchimiste";Id="1587123" });
			_context.SaveChanges();
			}	
		}

		//Méthode GET
		[HttpGet]
		public async Task<ActionResult<IEnumerable<Commentaire>>> GetCommentaire()
		{
			return await _context.commentaires.ToListAsync();
		}
		
		[HttpGet("{Id}")]
		public async Task<ActionResult<Commentaire>> GetCommentaire(long Id)
		{
			var commentaire = await _context.commentaires.FindAsync(Id);
			if ( commentaire == null)
			{
				return NotFound();
			}
			return commentaire;
		}

		//Méthode POST

		[HttpPost]
		public async Task<ActionResult<Commentaire>> PostCommentaire(Commentaire commentaire)
		{
			_context.commentaires.Add(commentaire);
			await _context.SaveChangesAsync();
			return CreatedAtAction(nameof(GetCommentaire), new {contenue=commentaire.contenue;reader= commentaire.reader;livre=commentaire.livre ;Id= commentaire.Id }, commentaire);
		}

		//Méthode PUT
		[HttpPut("{Id}")]
		public async Task<IActionResult> PutCommentaire(long Id,Commentaire commentaire)
		{
			if (Id != commentaire.Id)
			{
				return BadRequest();
			}
			_context.Entry(commentaire).State = EntityState.Modified;
			await _context.SaveChangesAsync();
			return NoContent();
		}


		//Méthode DELETE
		[HttpDelete("{id}")]
		public async Task<IActionResult> DeleteCommentaire(long id)
		{
			var commentaire = await _context.commentaires.FindAsync(id);
			if (commentaire == null)
			{
				return NotFound();
			}
			_context.commentaires.Remove(commentaire);
			await _context.SaveChangesAsync();
			return NoContent();
		}
	}
}