using System;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using namespace RESTWebClient
{
    public class Ouvrage
    {
        public string Id            { get; set; }
        public string titre         { get; set; }
        public string auteur        { get; set; }
        public long   nbExemplaire  { get; set; }
        public string editeur       { get; set; }
    }

    public class Commentaire
    {
        public string contenue { get; set; }
        public string reader { get; set; }
        public string livre { get; set; }
        public long Id { get; set; }
    }

      public class Abonne
    {
        public long Id{ get; set; }
        public string mdp { get; set; }
        
    }


	class Program
	{
		static HttpClient client = new HttpClient();

		/*************** Ouvrage ***************/
		static void ShowOuvrage(Ouvrage ouvrage)
		{
			Console.WriteLine($"Id: {ouvrage.Id}\tId: " +$"{ouvrage.titre}\ttitre: " +$"{ouvrage.auteur}\tauteur: " +$"{ouvrage.nbExemplaire}\tnbExemplaire: " +$"{ouvrage.editeur}\tediteur");
		}

		static async Task<Uri> CreateOuvrageAsync(Ouvrage ouvrage)
		{
			HttpResponseMessage response = await client.PostAsJsonAsync("api/ouvrage", ouvrage);
			response.EnsureSuccessStatusCode();// return URI of the created resource.
			return response.Headers.Location;
		}
		
		static async Task<Ouvrage> GetOuvrageAsync(string path)
		{
			Ouvrage ouvrage = null;
			HttpResponseMessage response = await client.GetAsync(path);
			if (response.IsSuccessStatusCode)
			{
				ouvrage = await response.Content.ReadAsAsync<ouvrage>();
			}
			return ouvrage;
		}
		static async Task<Ouvrage> UpdateOuvrageAsync(Ouvrage ouvrage)
		{
			HttpResponseMessage response = await client.PutAsJsonAsync($"api/ouvrage/{ouvrage.Id}", ouvrage);
			response.EnsureSuccessStatusCode();
			// Deserialize the updated Ouvrage from the response
			body.
			ouvrage = await response.Content.ReadAsAsync<Ouvrage>();
			return ouvrage;
		}
		
		static async Task<HttpStatusCode> DeleteOuvrageAsync(string id)
		{
			HttpResponseMessage response = await client.DeleteAsync($"api/ouvrage/{id}");
			return response.StatusCode;
		}

		/*************** Commentaire ***************/
		static void ShowCommentaire(Commentaire commentaire)
		{
			Console.WriteLine($"contenue: {commentaire.contenue}\treader: " +$"{commentaire.reader}\tlivre: " +$"{commentaire.livre}\tId: " +$"{commentaire.Id}");
		}

		static async Task<Uri> CreateCommentaireAsync(Commentaire commentaire)
		{
			HttpResponseMessage response = await client.PostAsJsonAsync("api/commentaire", commentaire);
			response.EnsureSuccessStatusCode();// return URI of the created resource.
			return response.Headers.Location;
		}
		
		static async Task<Commentaire> GetCommentaireAsync(string path)
		{
			Commentaire commentaire = null;
			HttpResponseMessage response = await client.GetAsync(path);
			if (response.IsSuccessStatusCode)
			{
				commentaire = await response.Content.ReadAsAsync<Commentaire>();
			}
			return commentaire;
		}
		static async Task<Commentaire> UpdateCommentaireAsync(Commentaire commentaire)
		{
			HttpResponseMessage response = await client.PutAsJsonAsync($"api/commentaire/{commentaire.Id}", commentaire);
			response.EnsureSuccessStatusCode();
			// Deserialize the updated Commentaire from the response
			body.
			commentaire = await response.Content.ReadAsAsync<Commentaire>();
			return commentaire;
		}
		
		static async Task<HttpStatusCode> DeleteCommentaireAsync(string id)
		{
			HttpResponseMessage response = await client.DeleteAsync($"api/commentaire/{id}");
			return response.StatusCode;
		}

		/*************** Abonne ***************/
		static void ShowAbonne(Abonne abonne)
		{
			Console.WriteLine($"Id: {abonne.Id}\tmdp: " +$"{abonne.mdp}");
		}

		static async Task<Uri> CreateAbonneAsync(Abonne abonne)
		{
			HttpResponseMessage response = await client.PostAsJsonAsync("api/abonne", abonne);
			response.EnsureSuccessStatusCode();// return URI of the created resource.
			return response.Headers.Location;
		}
		
		static async Task<Abonne> GetAbonneAsync(string path)
		{
			Abonne abonne = null;
			HttpResponseMessage response = await client.GetAsync(path);
			if (response.IsSuccessStatusCode)
			{
				abonne = await response.Content.ReadAsAsync<Abonne>();
			}
			return abonne;
		}
		static async Task<Abonne> UpdateAbonneAsync(Abonne abonne)
		{
			HttpResponseMessage response = await client.PutAsJsonAsync($"api/abonne/{abonne.Id}", abonne);
			response.EnsureSuccessStatusCode();
			// Deserialize the updated Abonne from the response
			body.
			abonne = await response.Content.ReadAsAsync<Abonne>();
			return abonne;
		}
		
		static async Task<HttpStatusCode> DeleteAbonneAsync(string id)
		{
			HttpResponseMessage response = await client.DeleteAsync($"api/abonne/{id}");
			return response.StatusCode;
		}



		
		static void Main()
		{
			RunAsync().GetAwaiter().GetResult();
		}
		
		static async Task RunAsync()
		{
			// Update port # in the following line.
			client.BaseAddress = newUri("http://localhost:64195/");
			client.DefaultRequestHeaders.Accept.Clear();
			client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("applica‐tion/json"));
			try
			{
				// Create a new Ouvrage
				Ouvrage ouvrage = new Ouvrage
				{
					Id="1",
					titre="l'alchimiste",
					auteur="paolo cohelo",
					nbExemplaire=50,
					editeur="casbah"
				};
				var url = await CreateOuvrageAsync(ouvrage);
				Console.WriteLine($"Created at {url}");
				// Get the Ouvrage
				ouvrage = await GetOuvrageAsync(url.PathAndQuery);
				ShowOuvrage(ouvrage);
				// Update the Ouvrage
				Console.WriteLine("Updating nbExemplaire...");
				ouvrage.nbExemplaire = 80;
				await UpdateOuvrageAsync(ouvrage);
				// Get the updated Ouvrage
				ouvrage = await GetOuvrageAsync(url.PathAndQuery);
				ShowOuvrage(ouvrage);
				// Delete the Ouvrage
				var statusCode = await DeleteOuvrageAsync(ouvrage.Id);
				Console.WriteLine($"Deleted (HTTP Status ={(int)statusCode})");

				// Create a new Commentaire
				Commentaire commentaire = new Commentaire
				{
					contenue="un bon livre , j'ai bien apprécié",
					reader="412215",		
					livre="KLNH-9568-NHGD-8512",
					Id="1587123"
				};
				var url = await CreateCommentaireAsync(commentaire);
				Console.WriteLine($"Created at {url}");
				// Get the Commentaire
				commentaire = await GetCommentaireAsync(url.PathAndQuery);
				ShowCommentaire(commentaire);
				// Update the Commentaire
				Console.WriteLine("Updating reader num...");
				commentaire.reader = 412220;
				await UpdateCommentaireAsync(commentaire);
				// Get the updated Commentaire
				commentaire = await GetCommentaireAsync(url.PathAndQuery);
				ShowCommentaire(commentaire);
				// Delete the Commentaire
				var statusCode = await DeleteCommentaireAsync(commentaire.Id);
				Console.WriteLine($"Deleted (HTTP Status ={(int)statusCode})");


				// Create a new Abonne
				Abonne abonne = new Abonne
				{
					Id="125486",
					mdp="*MPL!8/"
				};
				var url = await CreateAbonneAsync(abonne);
				Console.WriteLine($"Created at {url}");
				// Get the Abonne
				abonne = await GetAbonneAsync(url.PathAndQuery);
				ShowAbonne(abonne);
				// Update the Abonne
				Console.WriteLine("Updating abonne mdp...");
				abonne.mdp = "KL!^^0125;";
				await UpdateAbonneAsync(abonne);
				// Get the updated Abonne
				abonne = await GetAbonneAsync(url.PathAndQuery);
				ShowAbonne(abonne);
				// Delete the Abonne
				var statusCode = await DeleteAbonneAsync(abonne.Id);
				Console.WriteLine($"Deleted (HTTP Status ={(int)statusCode})");

			}catch (Exception e)
			{
				Console.WriteLine(e.Message);
			}
			Console.ReadLine();
		}
	}
}