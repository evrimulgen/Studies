package com.example.mterki.simpleinterface2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

/**
 * Created by pratap.kesaboyina on 10-06-2015.
 */
public class LoginActivity extends AppCompatActivity {


    LinearLayout layout1;
    private static int viewsCount = 0;
    private List<View> allViews = new ArrayList<View>();
    LinearLayout.LayoutParams params;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        // To set Margin for the child Views
        params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

        params.setMargins(5, 5, 5, 5);

        // LinearLayout acts as parent Layout , we will add child Views to this Layout dynamically
        layout1 = (LinearLayout) findViewById(R.id.layout1);
        // Sample Data for Spinner
        ArrayList<String> spinnerList = new ArrayList<String>();
        spinnerList.add("Select");
        spinnerList.add("Hyderabad");
        spinnerList.add("Banglore");
        spinnerList.add("Chennai");
        spinnerList.add("Delhi");
        spinnerList.add("Mumbai");

// create edittext dynamically , added to LinearLayout
        createEditText("First Name");
        createEditText("Last Name");
        createEditText("Age");
        createEditText("Address");
        createSpinner(spinnerList);
        createEditText("State");


// create spinners dynamically , added to LinearLayout


// create checkbox dynamically , added to LinearLayout
        createCheckBox("Key Contact");
        createCheckBox("Target contact");
        saveButton();

    }

    // create a button to show/save data , entered in the Form
    private void saveButton() {
        Button saveButton = new Button(this);
        saveButton.setHeight(WRAP_CONTENT);
        saveButton.setText("Save");
        saveButton.setOnClickListener(submitListener);
        layout1.addView(saveButton,params);
    }

    // Access the value of the EditText

    private View.OnClickListener submitListener = new View.OnClickListener() {
        public void onClick(View view) {
            StringBuilder stringBuilder = new StringBuilder();
            for (View singView : allViews) {

                String className = Utils.getClassName(singView.getClass());

                if (className.equalsIgnoreCase("EditText")) {
                    EditText editText = (EditText) singView;
                    stringBuilder.append(" "+editText.getText().toString());
                } else if (className.equalsIgnoreCase("Spinner")) {
                    Spinner spiner = (Spinner) singView;
                    stringBuilder.append(" "+spiner.getSelectedItem());
                }
                else if (className.equalsIgnoreCase("CheckBox")) {
                    CheckBox checkBox = (CheckBox) singView;
                    stringBuilder.append(" "+checkBox.isChecked());
                }

            }
            Log.i("All Data ", stringBuilder.toString());

            Utils.showAlertDialog(view.getContext(), "Data", stringBuilder.toString());
        }
    };


    public void createEditText(String hint) {
        EditText editText = new EditText(this);
        editText.setId(viewsCount++);
        editText.setHint(hint);
        allViews.add(editText);
        layout1.addView(editText,params);

    }

    public void createSpinner(List<String> spinnerList) {



        Spinner spinner = new Spinner(this);
        spinner.setId(viewsCount++);
        spinner.setBackgroundResource(R.drawable.ic_launcher_background);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, spinnerList);
        spinner.setAdapter(spinnerArrayAdapter);
        allViews.add(spinner);
        layout1.addView(spinner,params);
    }


    public void createCheckBox(String label) {

        final CheckBox checkBox = new CheckBox(this);
        checkBox.setId(viewsCount++);
        checkBox.setText(label);
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


            }
        });
        allViews.add(checkBox);
        layout1.addView(checkBox,params);
    }




}