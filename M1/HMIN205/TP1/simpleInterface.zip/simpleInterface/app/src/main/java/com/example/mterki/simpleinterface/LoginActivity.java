package com.example.mterki.simpleinterface;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.app.LoaderManager.LoaderCallbacks;

import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;

import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.READ_CONTACTS;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity  {

    /**
     * Id to identity READ_CONTACTS permission request.
     */
    private static final int REQUEST_READ_CONTACTS = 0;

    /**
     * A dummy authentication store containing known user names and passwords.
     * TODO: remove after connecting to a real authentication system.
     */
    private static final String[] DUMMY_CREDENTIALS = new String[]{
            "foo@example.com:hello", "bar@example.com:world"
    };
    /**
     * Keep track of the login task to ensure we can cancel it if requested.
     */
    private boolean isAllowed = false;

    // UI references.
    private EditText mFirstName;
    private EditText mLastName;
    private EditText mphone;
    private EditText mSkill;
    private EditText mAgeView;
    private EditText mAdress;


    private View mLoginFormView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Set up the login form.
        mFirstName = (EditText) findViewById(R.id.FirstName);
        mLastName = (EditText) findViewById(R.id.LastName);
        mphone = (EditText) findViewById(R.id.Phone);
        mSkill = (EditText) findViewById(R.id.skillDomain);
        mAgeView = (EditText) findViewById(R.id.Age);
        mAdress = (EditText) findViewById(R.id.LastName);
        mLoginFormView = findViewById(R.id.login_form);

    }

    private void verificationUser() {
        if (isAllowed != true) {
            return;
        }

        // Reset errors.
        mFirstName.setError(null);
        mLastName.setError(null);
        mphone.setError(null);
        mSkill.setError(null);
        mAgeView.setError(null);
        mAdress.setError(null);

        // Store values at the time of the login attempt.
        String firstName = mFirstName.getText().toString();
        String lastName = mLastName.getText().toString();
        String phone = mphone.getText().toString();
        String skill = mSkill.getText().toString();
        String age = mAgeView.getText().toString();
        String adress = mAdress.getText().toString();

        boolean cancel = false;
        View focusView = null;



        // Check for a valid first name.
        if (!TextUtils.isEmpty(firstName) ) {
            mFirstName.setError("Peénom  obligatoire");
            focusView = mFirstName;
            cancel = true;
        }

        // Check for a valid last name.
        if (!TextUtils.isEmpty(lastName) ) {
            mLastName.setError("Nom de famille  obligatoire");
            focusView = mLastName;
            cancel = true;
        }

        // Check for a valid age.
        if (!TextUtils.isEmpty(age) && !isAgeValid(Integer.parseInt(age)) ){
            mAgeView.setError("mineur !");
            focusView = mAgeView;
            cancel = true;
        }

        // Check for a valid  phone number.
        if (!TextUtils.isEmpty(phone) && !isPhoneNumber(phone) ) {
            mAgeView.setError("format inconnue !");
            focusView = mphone;
            cancel = true;
        }

        // Check for a valid adress.
        if (TextUtils.isEmpty(adress)) {
            mAdress.setError("adresse requise");
            focusView = mAdress;
            cancel = true;
        }


        if (cancel) {
            // There was an error; focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Confirmation de la validation

        }
    }

    private boolean isPhoneNumber(String phone) {
        //TODO: Replace this with your own logic
        return (phone.length() == 10);
    }

    private boolean isAgeValid(int Age) {
        //TODO: Replace this with your own logic
        return Age >= 18;
    }
}


