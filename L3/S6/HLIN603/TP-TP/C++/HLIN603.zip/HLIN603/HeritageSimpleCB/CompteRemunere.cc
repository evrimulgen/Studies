#include<iostream>
#include<string>
#include"CompteRemunere.h"
#include"CompteBancaire.h"
using namespace std;

CompteRemunere::~CompteRemunere(){ cout<<getSolde()*1.1<<" cr"<<endl;}
void CompteRemunere::deposer(double montant){
  montant*=1.01;
  this->solde = montant;
}
