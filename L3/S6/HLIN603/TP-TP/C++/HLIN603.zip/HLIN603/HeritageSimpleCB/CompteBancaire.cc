#include<iostream>
#include<string>
#include"CompteBancaire.h"

using namespace std;

CompteBancaire::~CompteBancaire(){ cout<<getSolde()<<" cb"<<endl;}
double CompteBancaire::getSolde() const{ return this->solde;}
void CompteBancaire::deposer(double montant){
  if(montant > 0) this->solde+=montant;
}
