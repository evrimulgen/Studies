#include<iostream>
#include<string>
#include"CompteDepot.h"
#include"CompteBancaire.h"
using namespace std;

CompteDepot::~CompteDepot(){ cout<<getSolde()-100<<" cd"<<endl;}
void CompteDepot::deposer(double montant){
  montant-=1;
  if(montant >= 1000) montant+=10;
  this->solde = montant;
}
