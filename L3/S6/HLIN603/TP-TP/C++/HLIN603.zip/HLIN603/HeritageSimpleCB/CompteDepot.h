#include"CompteBancaire.h"

#ifndef CompteDepot_h
#define CompteDepot_h

class CompteDepot: public virtual CompteBancaire {
  virtual ~CompteDepot();
public:
  void deposer(double);

};
#endif
