#include<iostream>
#include"CompteBancaire.h"
#include"CompteRemunere.h"
#include"CompteDepot.h"
#include"CompteRemunereAvecCarteCredit.h"

using namespace std;


int main(int argc, char const *argv[]) {
//  cout<<"donner le nombre de CB"<<endl;
int N = 4;
//  cin>>N;
  CompteBancaire **ComptesVP = new CompteBancaire*[N];

  CompteBancaire *cb = new CompteBancaire();
  CompteRemunere *cr = new CompteRemunere();
  CompteDepot *cd = new CompteDepot();
  CompteRemunereAvecCarteCredit *crcc = new CompteRemunereAvecCarteCredit();


  cb->deposer(12);
  cr->deposer(120);
  cd->deposer(12000);
  crcc->deposer(1400);

  ComptesVP[0] = cb;
  ComptesVP[1] = cr;
  ComptesVP[2] = cd;
  ComptesVP[3] = crcc;

  for(int i = 0; i < N; i++){
    cout<<ComptesVP[i]->getSolde()<<endl;
  }
/*
  for(int i = 0; i < N; i++){
    delete ComptesVP[i];
  }
*/
  return 0;
}
