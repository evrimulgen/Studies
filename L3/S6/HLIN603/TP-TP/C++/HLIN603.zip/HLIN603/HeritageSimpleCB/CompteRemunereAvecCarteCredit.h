#include"CompteRemunere.h"
#ifndef CompteRemunereAvecCarteCredit_h
#define CompteRemunereAvecCarteCredit_h

class CompteRemunereAvecCarteCredit: public virtual CompteRemunere{
public:
  virtual ~CompteRemunereAvecCarteCredit();
  //double deposer(double);
  //void deposer(int, string); pour que ça soit une surcharge.
};
#endif
