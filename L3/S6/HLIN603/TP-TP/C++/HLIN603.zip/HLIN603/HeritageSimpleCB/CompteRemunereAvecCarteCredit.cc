#include<iostream>
#include<string>
#include"CompteRemunere.h"
#include"CompteRemunereAvecCarteCredit.h"
using namespace std;

CompteRemunereAvecCarteCredit::~CompteRemunereAvecCarteCredit(){ cout<<getSolde()-5<<" cr"<<endl;}
double CompteRemunereAvecCarteCredit::deposer(double montant){
  CompteRemunere::deposer(montant);
  return getSolde();
}
