#ifndef CompteBancaire_h
#define CompteBancaire_h

class CompteBancaire{
protected:
  double solde;
public:
  virtual ~CompteBancaire();
  virtual void deposer(double);
  double getSolde() const;
};
#endif
