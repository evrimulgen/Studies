#include<string>
#include<iostream>
using namespace std;

#ifndef Strophe_h
#define Strophe_h
class Strophe{
private:
  Vers ** suiteVers;
  int nbVers;

public:
  Strophe();
  Strophe(Strophe&);
  virtual ~Strophe();
  virtual void saisie(istream& is);
  virtual Vers* vers(int i) ;
  virtual void affiche(ostream& os) const;

  //question2
  Strophe&  operator=(Strophe &s);
  //question3
  Vers*& operator[](int);
};

//question1
ostream& operator<<(ostream& os, Strophe& s);
istream& operator>>(istream& is, Strophe& s);

#endif
