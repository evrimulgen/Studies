#include<string>
#include<iostream>
using namespace std;
#ifndef vers_h
#define vers_h
  class Vers{
    private:
      string suiteMots;
      string rime;
    public:
      Vers();
      Vers(string);
      Vers(Vers&);
      Vers(string, string);
      virtual ~Vers();
      virtual string getSuiteMots() const;
      virtual void setSuiteMots(string);
      virtual string getRime() const;
      virtual void setRime(string);
      virtual void saisie(istream& is);
      virtual void affiche(ostream& os) const;

      Vers& operator=(Vers&);
  };
  //question1
  ostream& operator<<(ostream& os, Vers& v);
  istream& operator>>(istream& is, Vers& v);

#endif
