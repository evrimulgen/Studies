#include<iostream>
#include<string>
#include"Vers.h"
#include"Strophe.h"
using namespace std;

int main(int argc, char const *argv[]) {
  Strophe S;
  S.saisie(cin);
  cout << *S[0]<<endl;
  S[1] = new Vers("comme je descendais des fleuves impassibles", "ible");
  cout << *S[1] <<endl;
  return 0;
}
