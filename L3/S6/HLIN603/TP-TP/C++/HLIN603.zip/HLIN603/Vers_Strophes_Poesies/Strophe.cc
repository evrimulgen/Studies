#include<iostream>
#include<string>
using namespace std;
#include"Vers.h"
#include"Strophe.h"

Strophe::Strophe(){ suiteVers = NULL; nbVers = 0;}
Strophe::~Strophe(){if (suiteVers) delete[] suiteVers;}

Strophe::Strophe(Strophe& s){
  if(this != &s){
    if(this->suiteVers) delete[] suiteVers;
    this->nbVers = s.nbVers;
    this->suiteVers = new Vers*[s.nbVers];
    for(int i = 0; i < s.nbVers; i++){
      this->suiteVers[i] = s.suiteVers[i];
    }
  }
}

Vers* Strophe::vers(int i) {
  if(i >= 0 && i < nbVers) return suiteVers[i];
  else return NULL;
}

void Strophe::saisie(istream& is){
  if(suiteVers) delete[] suiteVers;
  cout << "Entrer le nombre de vers: "<<endl;
  is>>nbVers; suiteVers = new Vers*[nbVers];
  for(int i = 0; i < nbVers; i++){
    Vers *v=new Vers(); v->saisie(is); suiteVers[i]=v;
  }
}
void Strophe::affiche(ostream& os) const{
  for(int i = 0; i < nbVers; i++)
  {
    suiteVers[i]->affiche(os); os << endl;
  }
}

ostream& operator<<(ostream& os, Strophe& s){ s.affiche(os); return os;}
istream& operator>>(istream& is, Strophe& s){ s.saisie(is); return is;}

Strophe& Strophe::operator=(Strophe& s){
  if(this != &s){
    if(this->suiteVers) delete[] suiteVers;
    this->nbVers = s.nbVers;
    this->suiteVers = new Vers*[s.nbVers];
    for(int i = 0; i < s.nbVers; i++){
      this->suiteVers[i] = s.suiteVers[i];
    }
  }
  return *this;
}

Vers*& Strophe::operator[](int indice){ return suiteVers[indice]; }
