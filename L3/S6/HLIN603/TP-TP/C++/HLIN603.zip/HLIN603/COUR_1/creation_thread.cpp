#include <thread>
#include <iostream>

void my_thread_func(){
  std::cout<<"hello"<<std::endl;
}

int main(int argc, char const *argv[]) {
  //crée un objet thread qui lance l'exécution de my_thread_func
  std::thread t(my_thread_func);

  //attend la fin de l'exécution du thread (donc de my_thread_func)
  t.join();
  return 0;
}
