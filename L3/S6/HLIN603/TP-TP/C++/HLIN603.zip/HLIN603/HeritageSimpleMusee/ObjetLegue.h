#include<iostream>
#include<string>
#include"ObjetMusee.h"
using namespace std;

#ifndef ObjetLegue_h
#define ObjetLegue_h
class ObjetLegue : public virtual ObjetMusee {
private:
  string donateur;
  int annee;
public:
  ObjetLegue();
  ObjetLegue(string, string, int);

  string getDonateur() const;
  void setDonateur(string);
  int getAnnee() const;
  void setAnnee(int);
  void saisie(istream& is);
  void affiche(ostream& os);
};
#endif
