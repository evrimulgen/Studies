#include<iostream>
#include<string>
#include"ObjetMusee.h"
#include"ObjetLegue.h"
#include"ObjetArt.h"

#include"Salle.h"
using namespace std;

int main(int argc, char const *argv[]) {
  Salle *s1 = new Salle();
  ObjetArt * oa1 = new ObjetArt("haha", "mamadou");
  ObjetMusee *om1 = new ObjetMusee("hihi");
  s1->ajoute(*om1, 1);
  s1->ajoute(*om1, 2);
  s1->ajoute(*oa1, 3);
  (s1->enleve(1)).affiche(cout);
  cout<<endl;
  cout<<s1->objetPresent()<<endl;
  s1->affiche(cout);
  return 0;
}
