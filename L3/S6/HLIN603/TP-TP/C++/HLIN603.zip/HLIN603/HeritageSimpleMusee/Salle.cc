#include<iostream>
#include<string>
#include"ObjetMusee.h"
#include"ObjetArt.h"
#include"ObjetLegue.h"
#include"Salle.h"


Salle::Salle() : capacite(10){
  objet = new ObjetMusee*[10];
}
Salle::Salle(int c){
  if(c > 0){
    this->capacite = c;
    objet = new ObjetMusee*[c];
  }
  else cout<<"pas de valeur négative"<<endl;
}
Salle::~Salle(){
  if(objet) delete[] objet;
}

void Salle::ajoute(ObjetMusee& o, int i){
  if(i >= 0 && i < this->capacite){
    this->objet[i] = &o;
  }
  else cout<<"place inexistant"<<endl;
}

ObjetMusee& Salle::enleve(int i){
    ObjetMusee *o;
  if(i >= 0 && i < this->capacite){
    o = objet[i];
    objet[i] = NULL;
  }
  return *o;
}

void Salle::affiche(ostream& os){
  for(int i = 0; i < capacite; i++){
    objet[i]->affiche(os);
    cout<<endl;
  }
}

int Salle::objetPresent(){
  int cpt = 0;
  for(int i = 0; i < capacite; i++){
    if(objet[i]) cpt++;
  }
  return cpt;
}
