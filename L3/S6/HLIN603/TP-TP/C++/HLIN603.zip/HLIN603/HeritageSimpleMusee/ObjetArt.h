#include<iostream>
#include<string>
#include"ObjetMusee.h"
using namespace std;

#ifndef ObjetArt_h
#define ObjetArt_h
class ObjetArt: public virtual ObjetMusee{
private:
  string auteur;
public:
  ObjetArt();
  ObjetArt(string, string);

  string getAuteur() const;
  void saisie(istream& is);
  void affiche(ostream& os);
};
#endif
