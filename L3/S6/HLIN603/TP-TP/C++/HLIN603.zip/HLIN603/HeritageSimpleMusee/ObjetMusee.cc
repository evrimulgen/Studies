#include<iostream>
#include<string>
#include"ObjetMusee.h"

int ObjetMusee::index = 1;

ObjetMusee::ObjetMusee(){
  descriptif = "inconnue";
  reference = ObjetMusee::index;
  ObjetMusee::index++;
}
ObjetMusee::ObjetMusee(string d){
  descriptif = d;
  reference = ObjetMusee::index;
  ObjetMusee::index++;
}

string ObjetMusee::getDescriptif() const{ return descriptif;}
void ObjetMusee::setDescriptif(string s){ this->descriptif = s; }
int ObjetMusee::getReference() const { return this->reference; }

void ObjetMusee::saisie(istream& is){
  cout<<"descriptif"<<endl;
  is>>descriptif;
  this->reference = ObjetMusee::index;
}

void ObjetMusee::affiche(ostream& os){
  if(this != NULL)
    os<<this->reference<<" "<<this->descriptif<<" ";
  else os<<"NULL";
}
