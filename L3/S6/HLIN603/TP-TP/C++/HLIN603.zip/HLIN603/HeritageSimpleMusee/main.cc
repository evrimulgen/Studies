#include<iostream>
#include<string>
#include"ObjetLegue.h"
#include"ObjetMusee.h"
#include"ObjetArt.h"

int main(int argc, char const *argv[]) {
  ObjetMusee *om1 = new ObjetMusee();
  ObjetArt *oa1 = new ObjetArt("lala", "barry");
  ObjetLegue *ol1 = new ObjetLegue("loo", "djenabou", 1920);

  om1->affiche(cout);
  cout<<endl;
  oa1->affiche(cout);
  ol1->affiche(cout);

  ObjetMusee *m;
  m->saisie(cin);
  m->affiche(cout);
  return 0;
}
