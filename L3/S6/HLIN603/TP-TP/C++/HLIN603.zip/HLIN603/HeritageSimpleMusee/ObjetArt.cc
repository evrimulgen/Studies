#include<iostream>
#include<string>
#include"ObjetArt.h"
#include"ObjetMusee.h"

ObjetArt::ObjetArt() : ObjetMusee(){
  this->auteur = "inconue";
}

ObjetArt::ObjetArt(string d, string auteur) : ObjetMusee(d){
  this->auteur = auteur;
}

string ObjetArt::getAuteur() const{return this->auteur;}

void ObjetArt::saisie(istream& is){
  ObjetMusee::saisie(is);
  cout<<"auteur"<<endl;
  is>>auteur;
}

void ObjetArt::affiche(ostream& os){
  ObjetMusee::affiche(os);
  os<<auteur<<endl;
}
