#include"ObjetMusee.h"
using namespace std;
#ifndef Salle_h
#define Salle_h
class Salle{
private:
  int capacite;
  ObjetMusee **objet;
public:
  Salle();
  Salle(int);
  virtual ~Salle();

  void ajoute(ObjetMusee&, int);
  ObjetMusee& enleve(int);
  void affiche(ostream&);
  int objetPresent();
};
#endif
