#include<iostream>
#include<string>
using namespace std;

#ifndef ObjetMusee_h
#define ObjetMusee_h
class ObjetMusee{
private:
  string descriptif;
  int reference;
  static int index;

public:
  ObjetMusee();
  ObjetMusee(string);

  string getDescriptif() const;
  void setDescriptif(string);
  int getReference() const;
  void saisie(istream& is);
  void affiche(ostream& os);
};
#endif
