#include<iostream>
#include<string>
#include"ObjetLegue.h"
#include"ObjetMusee.h"

using namespace std;

ObjetLegue::ObjetLegue(){
  //ObjetMusee::ObjetMusee();
  this->donateur = "inconnue";
  this->annee = 0;
}

ObjetLegue::ObjetLegue(string d, string donateur, int annee) : ObjetMusee(d){

  this->donateur = donateur;
  setAnnee(annee);
}

string ObjetLegue::getDonateur() const{ return this->donateur;}
void ObjetLegue::setDonateur(string d){ this->donateur = d;}
int ObjetLegue::getAnnee() const{ return this->annee; }
void ObjetLegue::setAnnee(int a){
  if(a >= 0 && a < 2018) this->annee = a;
  else cout<<"la date n'est pas correct"<<endl;
}
void ObjetLegue::saisie(istream& is){
  ObjetMusee::saisie(is);
  cout<<"auteur et date"<<endl;
  is>>donateur>>annee;
}
void ObjetLegue::affiche(ostream& os){
  ObjetMusee::affiche(os);
  os<<donateur<<" "<<annee<<endl;

}
