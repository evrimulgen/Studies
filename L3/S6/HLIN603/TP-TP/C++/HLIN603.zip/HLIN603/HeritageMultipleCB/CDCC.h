#ifndef CDCC_H
#define CDCC_H
class CDCC : virtual public CompteDepot{
  
};
#endif;
