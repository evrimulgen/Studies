#include<iostream>
#include"CDCC.h"

using namespace std;
