#include<iostream>
#include"CDRCC.h"

using namespace std;
