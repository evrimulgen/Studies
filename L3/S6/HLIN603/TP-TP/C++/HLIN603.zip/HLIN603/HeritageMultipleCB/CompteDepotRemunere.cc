#include<iostream>
#include"CompteDepotRemunere.h"
using namespace std;

void CompteDepotRemunere::deposer(double){ //sinon conflit de nom

}
