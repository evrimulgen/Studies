#include<iostream>
#include"CompteRemunere.h"
using namespace std;


CompteRemunere::~CompteRemunere(){
  solde*=1.1;
  cout<<"la banque vous doit "<<solde<<" avec un intérêt de "<<solde*0.1<<endl;
}
void CompteRemunere::deposer(double montant){
  montant*=1.01;
  this->solde = montant;
}
