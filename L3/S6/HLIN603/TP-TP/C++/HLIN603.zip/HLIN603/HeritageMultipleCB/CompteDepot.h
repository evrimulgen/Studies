#include"CompteBancaire.h"

#ifndef CD_H
#define CD_H
class CompteDepot: public virtual CompteBancaire{
public:
  ~CompteDepot();
  virtual void deposer(double);
};
#endif
