#ifndef CB_H
#define CB_H
class CompteBancaire{
protected:
  double solde;
public:
  virtual ~CompteBancaire();
  virtual double getSolde() const;
  virtual void deposer(double);
};
#endif
