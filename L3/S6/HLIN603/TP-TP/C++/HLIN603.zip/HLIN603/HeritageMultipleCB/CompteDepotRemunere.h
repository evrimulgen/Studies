#include"CompteDepot.h"
#include"CompteRemunere.h"

#ifndef CDR_H
#define CDR_H
class CompteDepotRemunere: virtual public CompteRemunere, virtual public CompteDepot{
public:

  void deposer(double);
};
#endif
