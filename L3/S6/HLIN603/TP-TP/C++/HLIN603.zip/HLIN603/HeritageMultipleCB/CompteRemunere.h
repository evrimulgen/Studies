#include"CompteBancaire.h"

#ifndef CR_H
#define CR_H
class CompteRemunere: public virtual CompteBancaire{
public:
  ~CompteRemunere();
  virtual void deposer(double);
};
#endif
