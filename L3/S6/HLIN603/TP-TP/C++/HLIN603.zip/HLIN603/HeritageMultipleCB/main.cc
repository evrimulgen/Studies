#include<iostream>
#include"CompteBancaire.h"
#include"CompteDepot.h"
#include"CompteRemunere.h"
#include"CompteDepotRemunere.h"

using namespace std;

int main(int argc, char const *argv[]) {
  CompteBancaire *cb = new CompteBancaire();
  CompteRemunere *cr = new CompteRemunere();
  CompteDepot *cd = new CompteDepot();
  CompteDepotRemunere *cdr = new CompteDepotRemunere();

  cb->deposer(1000);
  cr->deposer(2000);
  cd->deposer(3000);

  delete cb;
  delete cr;
  delete cd;

  return 0;
}
