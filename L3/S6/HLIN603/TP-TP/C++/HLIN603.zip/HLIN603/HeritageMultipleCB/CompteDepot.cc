#include<iostream>
#include"CompteDepot.h"

using namespace std;
CompteDepot::~CompteDepot(){
  int franchise = 0;
  if(solde > 0){
    if(solde >= 100){
      franchise = 100;
      solde-=100;
    }
    else{
      franchise = solde;
      solde-=solde;
    }
    cout<<"la banque vous doit "<<solde<<" avec une franchise de "<<franchise<<endl;
  }
  else{
    cout<<"votre solde est trop bas, vous n'aurez pas de franchise"<<endl;
  }
}
void CompteDepot::deposer(double montant){
  if(solde > 0) montant-=1;
  if(montant >= 1000) montant+=10;
  this->solde = montant;
}
