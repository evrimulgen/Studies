#ifndef CDCC_H
#define CDCC_H
class CDRCC : virtual public CDCC, virtual public CompteRemunere{
  
};
#endif;
