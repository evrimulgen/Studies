#include<iostream>
#include"CompteBancaire.h"
using namespace std;


CompteBancaire::~CompteBancaire(){
  cout<<"la banque vous doit "<<solde<<endl;
}
double CompteBancaire::getSolde() const{ return this->solde;}
void CompteBancaire::deposer(double montant){
  if(montant > 0) this->solde+=montant;
}
