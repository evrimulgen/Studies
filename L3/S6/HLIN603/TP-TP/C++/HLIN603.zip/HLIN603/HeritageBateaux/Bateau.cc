#include<iostream>
#include"Bateau.h"

Bateau::~Bateau(){}
