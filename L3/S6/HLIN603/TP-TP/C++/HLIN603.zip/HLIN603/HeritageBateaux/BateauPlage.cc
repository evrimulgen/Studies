#include<iostream>
#include"Bateau.h"
#include"BateauPlage.h"

BateauPlage::~BateauPlage(){}
