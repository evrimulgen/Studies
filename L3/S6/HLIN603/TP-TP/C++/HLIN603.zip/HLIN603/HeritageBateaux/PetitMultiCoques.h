#ifndef PetitMultiCoques_h
#define PetitMultiCoques_h
class PetitMultiCoques: virtual public BateauPlage{
public:
  PetitMultiCoques() = default;
  virtual ~PetitMultiCoques();
  virtual int NbrCoques();
};
#endif;
