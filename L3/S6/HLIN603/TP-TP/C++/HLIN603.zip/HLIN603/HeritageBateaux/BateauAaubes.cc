#include<iostream>
#include<string>
#include"Bateau.h"
#include"BateauAaubes.h"

BateauAaubes::~BateauAaubes(){}
