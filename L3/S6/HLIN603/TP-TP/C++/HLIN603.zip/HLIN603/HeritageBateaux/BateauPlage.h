#ifndef BateauPlage_h
#define BateauPlage_h
class BateauPlage: virtual public Bateau{
protected:
  int DureeLocation;
public:
  BateauPlage() = default;
  virtual ~BateauPlage();
};
#endif;
