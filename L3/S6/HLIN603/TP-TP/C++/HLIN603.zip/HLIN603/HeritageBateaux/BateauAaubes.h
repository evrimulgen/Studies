#ifndef BateauAaubes_h
#define BateauAaubes_h
class BateauAaubes: virtual public Bateau{
protected:
  string ModeEntrainementAubes;
public:
  BateauAaubes() = default;
  virtual ~BateauAaubes();
};
#endif;
