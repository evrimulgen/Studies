#ifndef Bateau_h
#define Bateau_h
class Bateau{
protected:
  int NavZone;
public:
  Bateau() = default;
  virtual ~Bateau();
};
#endif;
