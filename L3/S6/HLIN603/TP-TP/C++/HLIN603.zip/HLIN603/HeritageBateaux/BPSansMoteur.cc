#include<iostream>
#include<string>
#include"BateauPlage.h"
#include"BPSansMoteur.h"

BPSansMoteur::~BPSansMoteur(){}
