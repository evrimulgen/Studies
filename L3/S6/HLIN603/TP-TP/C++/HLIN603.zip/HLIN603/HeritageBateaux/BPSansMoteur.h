#ifndef BPSansMoteur_h
#define BPSansMoteur_h
class BPSansMoteur: virtual public BateauPlage{
protected:
  string ModePropulsion;
public:
  BPSansMoteur() = default;
  virtual ~BPSansMoteur();
};
#endif;
