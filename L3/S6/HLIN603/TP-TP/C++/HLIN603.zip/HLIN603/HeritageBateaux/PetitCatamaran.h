#ifndef PetitCatamaran_h
#define PetitCatamaran_h
class PetitCatamaran: virtual public PetitMultiCoques{
protected:
  string ModePropulsion;
public:
  PetitCatamaran() = default;
  virtual ~PetitCatamaran();
};
#endif;
