#include<iostream>
#include<string>
#include"BateauPlage.h"
#include"PetitMultiCoques.h"

PetitMultiCoques::~PetitMultiCoques(){}

int PetitMultiCoques::NbrCoques(){
  return 5;
}
