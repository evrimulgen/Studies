#include<iostream>
#include<string>
#include"PetitMultiCoques.h"
#include"PetitCatamaran.h"

PetitCatamaran::~PetitCatamaran(){}
