Pharo 1.1-2018.01.16

This distribution was built January 16, 2018.
