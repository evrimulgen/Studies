#ifndef ABR_H
#define ABR_H

#include"noued.h"
#include<iostream>

using namespace std;

template <typename T>
Class Abr {
 private:
  Noeud<T> *n;

  Abr(){n.(NULL);};

  

  bool find(const &Noeud<T>);

  void load(&istream);

  void affiche const();

  void insert(const &Noeud<T>);

  T &plus_petit_ele const();
  T &plus_grand_ele const();

  ~Abr();};

#endif
#include"abr.tcc"
       
  

  













  };
#endif
