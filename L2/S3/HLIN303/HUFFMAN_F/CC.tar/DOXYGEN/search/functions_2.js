var searchData=
[
  ['decalage',['decalage',['../conversions_8c.html#abca2e493bd0339d22622222d9bdbd3bb',1,'decalage(char *s, int i):&#160;conversions.c'],['../conversions_8h.html#ae60a5339fb1112d280228982bfe98e4b',1,'decalage(char *s, int i):&#160;conversions.c']]]
];
