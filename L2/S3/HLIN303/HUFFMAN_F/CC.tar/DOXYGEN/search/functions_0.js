var searchData=
[
  ['btoi',['btoi',['../conversions_8c.html#a0d9eca74a4d7a1e3e0f3da281d8fdab7',1,'btoi(const char *s):&#160;conversions.c'],['../conversions_8h.html#adc3f14c9f9e46c973b2a4000ddf1824d',1,'btoi(const char *s):&#160;conversions.c']]],
  ['buffeur',['buffeur',['../conversions_8c.html#a597259d8efe1f76897e6bf91bc7b1a6b',1,'buffeur(int j, int c, FILE *f):&#160;conversions.c'],['../conversions_8h.html#a6e75c38ad9a26698208cb5c3bccf4692',1,'buffeur(int j, int c, FILE *f):&#160;conversions.c']]]
];
