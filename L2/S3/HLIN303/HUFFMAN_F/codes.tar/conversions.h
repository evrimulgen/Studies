#include<stdio.h>
/**
 * \file conversions.h
 * \author Terki-Adel
 */ 
                  

char* ctob(int a);


int btoi(const char* s);


char* buffeur(int j,int c,FILE* f);



void decalage (char* s,int i);



