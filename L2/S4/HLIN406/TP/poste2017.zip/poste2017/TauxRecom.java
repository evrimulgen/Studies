package poste2017;

public enum TauxRecom {
	faible, moyen, fort;
}
